# ALF Homework 3 - Sematic AST

## Description

You can find here the public tests for homework 3.

## Questions

If you have any questions, please open an issue.

## Tests 

You need bash (Linux or Windows Linux Subsystem) to run the tests.

Clone this repository into a folder and copy it's contents to your homework folder.

Run

````bash
make -f Makefile.checker
````
